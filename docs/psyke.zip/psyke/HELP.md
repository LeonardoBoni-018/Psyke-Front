# Psyke - Help & Reference

## Quick Start

```bash
docker compose up -d
.\mvnw.cmd spring-boot:run
```

Open: [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

## Useful Maven Commands

| Command | Description |
|---------|-------------|
| `.\mvnw.cmd test` | Run all tests |
| `.\mvnw.cmd test -Dtest=ClassNameTest` | Run single test class |
| `.\mvnw.cmd clean package -DskipTests` | Build JAR |
| `.\mvnw.cmd spring-boot:run` | Start development server |
| `.\mvnw.cmd dependency:tree` | Show dependency tree |

## Documentation

- [README.md](./README.md) — Full project overview
- [AGENTS.md](./AGENTS.md) — Development context for AI agents
- [pom.xml](./pom.xml) — Maven configuration and dependencies

## External References

- [Spring Boot 4.0.6](https://docs.spring.io/spring-boot/4.0.6)
- [Spring Security](https://docs.spring.io/spring-boot/4.0.6/reference/web/spring-security.html)
- [SpringDoc OpenAPI](https://springdoc.org/)
- [OpenPDF](https://github.com/LibrePDF/OpenPDF)
- [Twilio SDK](https://www.twilio.com/docs/libraries/java)
