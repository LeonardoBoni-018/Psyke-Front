package com.br.psyke.psyke.exception;

public class SlotConflictException extends RuntimeException {
    public SlotConflictException(String message) { super(message); }
}
